<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Course-level time tracking configuration page.
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once("../../config.php");
require_once($CFG->dirroot . "/blocks/configurable_reports/locallib.php");
require_once($CFG->dirroot . "/blocks/configurable_reports/course_time_config_form.php");

$courseid = required_param('courseid', PARAM_INT);
$consolidate = optional_param('consolidate', 0, PARAM_INT);

if (!$course = $DB->get_record('course', ['id' => $courseid])) {
    throw new moodle_exception('invalidcourseid');
}

require_login($course);
$context = context_course::instance($course->id);
require_capability('block/configurable_reports:managereports', $context);

$PAGE->set_url('/blocks/configurable_reports/course_time_config.php', ['courseid' => $courseid]);
$PAGE->set_context($context);
$PAGE->set_pagelayout('incourse');

// Handle manual consolidation request.
if ($consolidate && confirm_sesskey()) {
    // Check that the table exists.
    $tableexists = false;
    try {
        $tableexists = $DB->get_manager()->table_exists('configurable_reports_diario');
    } catch (Throwable $t) {
        $tableexists = false;
    }

    if ($tableexists) {
        $trace = new null_progress_trace();
        $result = \block_configurable_reports\consolidation_helper::consolidate_course($courseid, $trace);
        $trace->finished();

        // Save last consolidation timestamp for this course.
        set_config('last_consolidation_' . $courseid, time(), 'block_configurable_reports');

        redirect(
            new moodle_url('/blocks/configurable_reports/course_time_config.php', ['courseid' => $courseid]),
            get_string('consolidation_success', 'block_configurable_reports',
                (object)[
                    'users' => $result['users_processed'],
                    'records' => $result['records_written'],
                ]
            ),
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );
    } else {
        redirect(
            new moodle_url('/blocks/configurable_reports/course_time_config.php', ['courseid' => $courseid]),
            get_string('consolidation_notable', 'block_configurable_reports'),
            null,
            \core\output\notification::NOTIFY_ERROR
        );
    }
}

$configkey = 'max_daily_hours_' . $courseid;

$mform = new course_time_config_form(null, [
    'courseid' => $courseid,
]);

if ($mform->is_cancelled()) {
    redirect(new moodle_url('/course/view.php', ['id' => $courseid]));

} else if ($data = $mform->get_data()) {
    $value = max(0, (int)($data->max_daily_hours ?? 0));
    set_config($configkey, $value, 'block_configurable_reports');

    redirect(
        new moodle_url('/blocks/configurable_reports/course_time_config.php', ['courseid' => $courseid]),
        get_string('changessaved')
    );

} else {
    // Pre-populate form with saved value.
    $defaults = new stdClass();
    $defaults->courseid = $courseid;
    $saved = get_config('block_configurable_reports', $configkey);
    $defaults->max_daily_hours = ($saved !== false) ? (int)$saved : 0;
    $mform->set_data($defaults);
}

$title = get_string('coursetimeconfig', 'block_configurable_reports');
$PAGE->navbar->add(get_string('managereports', 'block_configurable_reports'),
    new moodle_url('/blocks/configurable_reports/managereport.php', ['courseid' => $courseid]));
$PAGE->navbar->add($title);
$PAGE->set_title($title);
$PAGE->set_heading($title);

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
