<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Scheduled task to consolidate daily connection times.
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_configurable_reports\task;

defined('MOODLE_INTERNAL') || die();

/**
 * Scheduled task that pre-computes daily connection time totals
 * into the configurable_reports_diario table.
 */
class consolidate_daily_times extends \core\task\scheduled_task {

    /**
     * Return the task's name as shown in admin screens.
     *
     * @return string
     */
    public function get_name(): string {
        return get_string('task_consolidate_daily_times', 'block_configurable_reports');
    }

    /**
     * Execute the task.
     */
    public function execute(): void {
        global $DB;

        // Make sure the table exists before running.
        try {
            if (!$DB->get_manager()->table_exists('configurable_reports_diario')) {
                mtrace('  Table configurable_reports_diario does not exist yet. Skipping consolidation.');
                return;
            }
        } catch (\Throwable $t) {
            mtrace('  Error checking for configurable_reports_diario table: ' . $t->getMessage());
            return;
        }

        $trace = new \text_progress_trace();
        \block_configurable_reports\consolidation_helper::consolidate_all($trace);
        $trace->finished();
    }
}
