<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Form for course-level time tracking configuration.
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir . '/formslib.php');

/**
 * Form for configuring time tracking caps at course level.
 *
 * @package block_configurable_reports
 */
class course_time_config_form extends moodleform {

    /**
     * Form definition.
     */
    public function definition() {
        $mform    = $this->_form;
        $courseid = $this->_customdata['courseid'];

        // --- Section 1: Max daily hours setting ---
        $mform->addElement(
            'header',
            'timetrackingheader',
            get_string('coursetimeconfig', 'block_configurable_reports')
        );

        $mform->addElement(
            'text',
            'max_daily_hours',
            get_string('maxdailyhours', 'block_configurable_reports')
        );
        $mform->setType('max_daily_hours', PARAM_INT);
        $mform->setDefault('max_daily_hours', 0);
        $mform->addHelpButton('max_daily_hours', 'maxdailyhours', 'block_configurable_reports');
        $mform->addRule('max_daily_hours', get_string('error'), 'numeric', null, 'client');

        $mform->addElement('hidden', 'courseid', $courseid);
        $mform->setType('courseid', PARAM_INT);

        $this->add_action_buttons(true, get_string('savechanges'));

        // --- Section 2: Manual consolidation ---
        $mform->addElement(
            'header',
            'consolidationheader',
            get_string('consolidation_header', 'block_configurable_reports')
        );

        $mform->addElement(
            'static',
            'consolidation_desc',
            '',
            get_string('consolidation_desc', 'block_configurable_reports')
        );

        // Show last consolidation time if available.
        $lastrun = get_config('block_configurable_reports', 'last_consolidation_' . $courseid);
        if ($lastrun) {
            $mform->addElement(
                'static',
                'last_consolidation',
                get_string('consolidation_lastrun', 'block_configurable_reports'),
                userdate((int)$lastrun)
            );
        }

        $consolidateurl = new moodle_url(
            '/blocks/configurable_reports/course_time_config.php',
            ['courseid' => $courseid, 'consolidate' => 1, 'sesskey' => sesskey()]
        );
        $mform->addElement(
            'static',
            'consolidate_button',
            '',
            \html_writer::link(
                $consolidateurl,
                get_string('consolidation_run', 'block_configurable_reports'),
                ['class' => 'btn btn-secondary']
            )
        );
    }

    /**
     * Validate the form data.
     *
     * @param array $data
     * @param array $files
     * @return array
     */
    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        $value = (int)($data['max_daily_hours'] ?? 0);
        if ($value < 0) {
            $errors['max_daily_hours'] = get_string('maxdailyhours_error', 'block_configurable_reports');
        }
        if ($value > 24) {
            $errors['max_daily_hours'] = get_string('maxdailyhours_error_max', 'block_configurable_reports');
        }

        return $errors;
    }
}
