<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper class for the Traceability Report (Informe de Trazabilidad).
 *
 * Provides queries that fill the data gaps not already covered by
 * the existing userstatsadvanced stat_types. Specifically:
 *
 *  1. Videoconference attendance (BigBlueButton / Zoom via logstore).
 *  2. Detailed material / resource access (first access, last access per resource).
 *  3. Complete messaging bodies (tutor <-> student email content).
 *  4. Tutor time separation (task-correction time vs tutoring / messaging time).
 *  5. Course summary data (header of traceability report).
 *  6. Detailed connection log (entry/exit/elapsed/IP per session).
 *  7. SCORM detail and evaluation detail wrappers.
 *
 * All methods are static so they can be called from both the report column
 * (stat_types in userstatsadvanced) and the PDF export script.
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_configurable_reports;

defined('MOODLE_INTERNAL') || die();

class traceability_helper {

    // =========================================================================
    // 1. VIDEOCONFERENCES
    // =========================================================================

    /**
     * Get videoconference sessions for a user in a course.
     *
     * Checks BigBlueButton (mod_bigbluebuttonbn) logs first, then falls
     * back to Zoom (mod_zoom) if available. Also checks logstore for
     * generic videoconference module events.
     *
     * @param int $userid
     * @param int $courseid
     * @return array Each element: [name, date, join_time, leave_time, duration_seconds, source]
     */
    public static function get_videoconference_sessions(int $userid, int $courseid): array {
        global $DB;

        $sessions = [];
        $dbman = $DB->get_manager();

        // --- BigBlueButton (mod_bigbluebuttonbn) ---
        if ($dbman->table_exists('bigbluebuttonbn_logs') && $dbman->table_exists('bigbluebuttonbn')) {
            $sessions = array_merge($sessions, self::get_bbb_sessions($userid, $courseid));
        }

        // --- Zoom (mod_zoom) ---
        if ($dbman->table_exists('zoom_meeting_participants') && $dbman->table_exists('zoom')) {
            $sessions = array_merge($sessions, self::get_zoom_sessions($userid, $courseid));
        }

        // --- Fallback: logstore events for any videoconference module ---
        if (empty($sessions)) {
            $sessions = self::get_videoconf_from_logstore($userid, $courseid);
        }

        usort($sessions, function ($a, $b) {
            return ($a['join_time'] ?? 0) <=> ($b['join_time'] ?? 0);
        });

        return $sessions;
    }

    /**
     * Get BigBlueButton session data from bigbluebuttonbn_logs.
     */
    private static function get_bbb_sessions(int $userid, int $courseid): array {
        global $DB;

        $sql = "SELECT bl.id, bl.bigbluebuttonbnid, bl.timecreated, bl.log, bl.meta,
                       b.name AS session_name
                  FROM {bigbluebuttonbn_logs} bl
                  JOIN {bigbluebuttonbn} b ON b.id = bl.bigbluebuttonbnid
                 WHERE bl.userid = :userid
                   AND bl.courseid = :courseid
                   AND bl.log IN ('Join', 'Create')
              ORDER BY bl.timecreated ASC";

        $records = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);
        $sessions = [];

        foreach ($records as $rec) {
            $sessions[] = [
                'name'             => $rec->session_name,
                'date'             => date('d/m/Y', $rec->timecreated),
                'join_time'        => (int)$rec->timecreated,
                'leave_time'       => 0,
                'duration_seconds' => 0,
                'source'           => 'bigbluebuttonbn',
            ];
        }

        self::estimate_bbb_durations($sessions, $userid, $courseid);
        return $sessions;
    }

    /**
     * Estimate BBB session durations by looking at subsequent events.
     */
    private static function estimate_bbb_durations(array &$sessions, int $userid, int $courseid): void {
        global $DB;

        if (empty($sessions)) {
            return;
        }

        $sql = "SELECT bl.id, bl.bigbluebuttonbnid, bl.timecreated, bl.log
                  FROM {bigbluebuttonbn_logs} bl
                 WHERE bl.userid = :userid
                   AND bl.courseid = :courseid
              ORDER BY bl.timecreated ASC";
        $allevents = array_values($DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]));
        $count = count($allevents);

        foreach ($sessions as &$session) {
            $jointime = $session['join_time'];
            for ($i = 0; $i < $count; $i++) {
                if ((int)$allevents[$i]->timecreated === $jointime) {
                    for ($j = $i + 1; $j < $count; $j++) {
                        $delta = (int)$allevents[$j]->timecreated - $jointime;
                        if ($delta > 0 && $delta <= 14400) {
                            $session['leave_time'] = (int)$allevents[$j]->timecreated;
                            $session['duration_seconds'] = $delta;
                        }
                        break;
                    }
                    break;
                }
            }
        }
        unset($session);
    }

    /**
     * Get Zoom session data (when mod_zoom is installed).
     */
    private static function get_zoom_sessions(int $userid, int $courseid): array {
        global $DB;

        $sql = "SELECT zp.id, z.name AS session_name, zp.join_time, zp.leave_time,
                       zp.duration
                  FROM {zoom_meeting_participants} zp
                  JOIN {zoom_meeting_details} zmd ON zmd.id = zp.detailsid
                  JOIN {zoom} z ON z.id = zmd.zoomid
                 WHERE z.course = :courseid
                   AND (zp.userid = :userid OR zp.userid = 0)
              ORDER BY zp.join_time ASC";

        try {
            $records = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);
        } catch (\Throwable $e) {
            return [];
        }

        $sessions = [];
        foreach ($records as $rec) {
            $jointime = (int)$rec->join_time;
            $leavetime = (int)$rec->leave_time;
            $duration = (int)$rec->duration;
            if ($jointime <= 0 && $duration <= 0) {
                continue;
            }
            $sessions[] = [
                'name'             => $rec->session_name,
                'date'             => $jointime > 0 ? date('d/m/Y', $jointime) : '-',
                'join_time'        => $jointime,
                'leave_time'       => $leavetime,
                'duration_seconds' => $duration > 0 ? $duration : max(0, $leavetime - $jointime),
                'source'           => 'zoom',
            ];
        }
        return $sessions;
    }

    /**
     * Fallback: extract videoconference access from logstore for any VC module.
     */
    private static function get_videoconf_from_logstore(int $userid, int $courseid): array {
        global $DB;

        $components = ['mod_bigbluebuttonbn', 'mod_zoom', 'mod_jitsi', 'mod_webexactivity'];
        [$insql, $params] = $DB->get_in_or_equal($components, SQL_PARAMS_NAMED, 'comp');
        $params['userid'] = $userid;
        $params['courseid'] = $courseid;

        $sql = "SELECT l.id, l.timecreated, l.component, l.action, l.contextinstanceid
                  FROM {logstore_standard_log} l
                 WHERE l.userid = :userid
                   AND l.courseid = :courseid
                   AND l.component $insql
                   AND l.action = 'viewed'
              ORDER BY l.timecreated ASC";

        try {
            $records = $DB->get_records_sql($sql, $params);
        } catch (\Throwable $e) {
            return [];
        }

        $sessions = [];
        foreach ($records as $rec) {
            $cmid = (int)$rec->contextinstanceid;
            $modname = str_replace('mod_', '', $rec->component);
            $name = self::get_activity_name_by_cmid($cmid, $modname);

            $sessions[] = [
                'name'             => $name ?: $rec->component,
                'date'             => date('d/m/Y', $rec->timecreated),
                'join_time'        => (int)$rec->timecreated,
                'leave_time'       => 0,
                'duration_seconds' => 0,
                'source'           => 'logstore_' . $rec->component,
            ];
        }
        return $sessions;
    }

    /**
     * Count total videoconference sessions for a user in a course.
     */
    public static function count_videoconference_sessions(int $userid, int $courseid): int {
        return count(self::get_videoconference_sessions($userid, $courseid));
    }


    // =========================================================================
    // 2. MATERIAL / RESOURCE ACCESS DETAILS
    // =========================================================================

    /**
     * Get detailed resource access records for a user in a course.
     *
     * Returns first access, last access and access count for every
     * resource/activity in the course.
     *
     * @param int $userid
     * @param int $courseid
     * @return array Each: [cmid, name, modname, first_access, last_access, access_count]
     */
    public static function get_material_access_details(int $userid, int $courseid): array {
        global $DB;

        $sql = "SELECT cm.id AS cmid, cm.module, cm.instance, cm.section,
                       m.name AS modname
                  FROM {course_modules} cm
                  JOIN {modules} m ON m.id = cm.module
                 WHERE cm.course = :courseid
                   AND cm.deletioninprogress = 0
              ORDER BY cm.section ASC, cm.id ASC";
        $modules = $DB->get_records_sql($sql, ['courseid' => $courseid]);

        if (empty($modules)) {
            return [];
        }

        $sql = "SELECT l.contextinstanceid AS cmid,
                       MIN(l.timecreated) AS first_access,
                       MAX(l.timecreated) AS last_access,
                       COUNT(l.id) AS access_count
                  FROM {logstore_standard_log} l
                 WHERE l.userid = :userid
                   AND l.courseid = :courseid
                   AND l.contextlevel = :contextmodule
                   AND l.action = 'viewed'
              GROUP BY l.contextinstanceid";
        $accessdata = $DB->get_records_sql($sql, [
            'userid'        => $userid,
            'courseid'      => $courseid,
            'contextmodule' => CONTEXT_MODULE,
        ]);

        $results = [];
        foreach ($modules as $mod) {
            $cmid = (int)$mod->cmid;
            $name = self::get_activity_name_by_cmid($cmid, $mod->modname);
            $access = isset($accessdata[$cmid]) ? $accessdata[$cmid] : null;

            $results[] = [
                'cmid'         => $cmid,
                'name'         => $name ?: get_string('pluginname', 'mod_' . $mod->modname),
                'modname'      => $mod->modname,
                'first_access' => $access ? (int)$access->first_access : 0,
                'last_access'  => $access ? (int)$access->last_access : 0,
                'access_count' => $access ? (int)$access->access_count : 0,
            ];
        }
        return $results;
    }

    /**
     * Get only the accessed materials (non-zero access count).
     */
    public static function get_accessed_materials(int $userid, int $courseid): array {
        return array_values(array_filter(
            self::get_material_access_details($userid, $courseid),
            function ($item) { return $item['access_count'] > 0; }
        ));
    }


    // =========================================================================
    // 3. COMPLETE MESSAGING (full bodies, not just counts)
    // =========================================================================

    /**
     * Get full message records between a user and course members.
     *
     * @param int $userid
     * @param int $courseid
     * @param array $targetarchetypes Role archetypes to filter, e.g. ['editingteacher','teacher'].
     *                                 Empty = all course members.
     * @return array Each: [id, timecreated, useridfrom, useridto, from_fullname, to_fullname, subject, body]
     */
    public static function get_complete_messages(int $userid, int $courseid, array $targetarchetypes = []): array {
        global $DB;

        $targetids = self::get_course_user_ids_by_archetypes($courseid, $targetarchetypes, $userid);
        if (empty($targetids)) {
            return [];
        }

        $dbman = $DB->get_manager();
        $messages = [];

        if ($dbman->table_exists('message_messages') && $dbman->table_exists('message_conversation_members')) {
            $messages = self::get_messages_modern($userid, $targetids);
        }

        usort($messages, function ($a, $b) {
            return ($a['timecreated'] ?? 0) <=> ($b['timecreated'] ?? 0);
        });
        return $messages;
    }

    /**
     * Get messages using the modern Moodle messaging tables (3.6+).
     */
    private static function get_messages_modern(int $userid, array $targetids): array {
        global $DB;

        if (empty($targetids)) {
            return [];
        }

        [$insql, $inparams] = $DB->get_in_or_equal($targetids, SQL_PARAMS_NAMED, 'tgt1');
        [$insql2, $inparams2] = $DB->get_in_or_equal($targetids, SQL_PARAMS_NAMED, 'tgt2');

        $sql = "SELECT DISTINCT mm.id AS msgid,
                       mm.useridfrom,
                       mm.subject,
                       mm.smallmessage,
                       mm.fullmessage,
                       mm.timecreated,
                       mm.conversationid
                  FROM {message_messages} mm
                  JOIN {message_conversation_members} mcm_user
                    ON mcm_user.conversationid = mm.conversationid
                   AND mcm_user.userid = :userid
                  JOIN {message_conversation_members} mcm_target
                    ON mcm_target.conversationid = mm.conversationid
                   AND mcm_target.userid $insql
                 WHERE (mm.useridfrom = :useridfrom OR mm.useridfrom $insql2)
              ORDER BY mm.timecreated ASC";

        $params = array_merge(
            ['userid' => $userid, 'useridfrom' => $userid],
            $inparams,
            $inparams2
        );

        try {
            $records = $DB->get_records_sql($sql, $params);
        } catch (\Throwable $e) {
            return [];
        }

        $usernames = self::load_user_fullnames(array_merge([$userid], $targetids));

        $messages = [];
        foreach ($records as $rec) {
            $fromid = (int)$rec->useridfrom;
            $toid = ($fromid === $userid)
                ? self::get_other_member_in_conversation((int)$rec->conversationid, $userid, $targetids)
                : $userid;

            $body = !empty($rec->fullmessage) ? $rec->fullmessage : ($rec->smallmessage ?? '');

            $messages[] = [
                'id'            => (int)$rec->msgid,
                'timecreated'   => (int)$rec->timecreated,
                'useridfrom'    => $fromid,
                'useridto'      => $toid,
                'from_fullname' => $usernames[$fromid] ?? "User #{$fromid}",
                'to_fullname'   => $usernames[$toid] ?? "User #{$toid}",
                'subject'       => $rec->subject ?? '',
                'body'          => $body,
            ];
        }
        return $messages;
    }

    /**
     * Get the other member in a conversation from among target IDs.
     */
    private static function get_other_member_in_conversation(int $conversationid, int $excludeuserid, array $targetids): int {
        global $DB;

        [$insql, $params] = $DB->get_in_or_equal($targetids, SQL_PARAMS_NAMED, 'conv');
        $params['conversationid'] = $conversationid;
        $params['excludeuser'] = $excludeuserid;

        $sql = "SELECT mcm.userid
                  FROM {message_conversation_members} mcm
                 WHERE mcm.conversationid = :conversationid
                   AND mcm.userid <> :excludeuser
                   AND mcm.userid $insql";

        try {
            $records = $DB->get_records_sql($sql, $params, 0, 1);
            $rec = reset($records);
            return $rec ? (int)$rec->userid : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }


    // =========================================================================
    // 4. TUTOR TIME SEPARATION (task correction vs tutoring)
    // =========================================================================

    /**
     * Estimate tutor's time spent on task correction vs tutoring/messaging.
     *
     * "Task correction time" = time in assign grading pages + quiz review pages.
     * "Tutoring time" = time in messaging, forum, and other communication activities.
     *
     * @param int $userid  The tutor's user ID.
     * @param int $courseid
     * @return array [task_correction_seconds, tutoring_seconds, total_seconds]
     */
    public static function get_tutor_time_breakdown(int $userid, int $courseid): array {
        global $DB;

        $sessionlimit = 14400;
        $taskcomponents = ['mod_assign', 'mod_quiz', 'mod_workshop'];
        $tutoringcomponents = ['mod_forum', 'core_message', 'mod_chat', 'mod_feedback'];

        $sql = "SELECT l.id, l.timecreated, l.component, l.action, l.eventname
                  FROM {logstore_standard_log} l
                 WHERE l.userid = :userid
                   AND l.courseid = :courseid
              ORDER BY l.timecreated ASC";
        $logs = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);

        if (empty($logs)) {
            return ['task_correction_seconds' => 0, 'tutoring_seconds' => 0, 'total_seconds' => 0];
        }

        $taskseconds = 0;
        $tutoringseconds = 0;
        $totalseconds = 0;
        $prev = null;
        $prevtype = 'other';

        foreach ($logs as $log) {
            $currenttime = (int)$log->timecreated;
            $component = (string)$log->component;

            $currenttype = 'other';
            if (in_array($component, $taskcomponents, true)) {
                $currenttype = 'task';
            } else if (in_array($component, $tutoringcomponents, true)) {
                $currenttype = 'tutoring';
            }

            if ($prev !== null) {
                $delta = $currenttime - (int)$prev->timecreated;
                if ($delta > 0 && $delta <= $sessionlimit) {
                    $totalseconds += $delta;
                    if ($prevtype === 'task') {
                        $taskseconds += $delta;
                    } else if ($prevtype === 'tutoring') {
                        $tutoringseconds += $delta;
                    }
                }
            }

            $prev = $log;
            $prevtype = $currenttype;
        }

        return [
            'task_correction_seconds' => $taskseconds,
            'tutoring_seconds'        => $tutoringseconds,
            'total_seconds'           => $totalseconds,
        ];
    }


    // =========================================================================
    // 5. COURSE SUMMARY DATA (header of traceability report)
    // =========================================================================

    /**
     * Get course summary data for the traceability report header.
     *
     * @param int $courseid
     * @return array
     */
    public static function get_course_summary(int $courseid): array {
        global $DB;

        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $context = \context_course::instance($courseid);

        $students = get_enrolled_users($context, 'mod/assign:submit', 0, 'u.id');
        $studentcount = count($students);

        $teachers = get_enrolled_users($context, 'moodle/course:update', 0, 'u.id');
        $tutorcount = count($teachers);

        $examcount = $DB->count_records('quiz', ['course' => $courseid]);
        $scormcount = $DB->count_records('scorm', ['course' => $courseid]);

        $lessoncount = $DB->count_records_select('course_modules',
            'course = :courseid AND deletioninprogress = 0',
            ['courseid' => $courseid]
        );

        $videoconfcount = 0;
        $dbman = $DB->get_manager();
        if ($dbman->table_exists('bigbluebuttonbn')) {
            $videoconfcount += $DB->count_records('bigbluebuttonbn', ['course' => $courseid]);
        }
        if ($dbman->table_exists('zoom')) {
            $videoconfcount += $DB->count_records('zoom', ['course' => $courseid]);
        }

        $totalhours = 0;
        if (!empty($course->enddate) && !empty($course->startdate) && $course->enddate > $course->startdate) {
            $totalhours = round(($course->enddate - $course->startdate) / 3600);
        }

        // Try to get campus from custom course field.
        $campus = '';
        try {
            $handler = \core_customfield\handler::get_handler('core_course', 'course');
            $datas = $handler->get_instance_data($courseid);
            foreach ($datas as $data) {
                $field = $data->get_field();
                $shortname = $field->get('shortname');
                if (stripos($shortname, 'campus') !== false || stripos($shortname, 'sede') !== false) {
                    $campus = $data->export_value();
                    break;
                }
            }
        } catch (\Throwable $e) {
            // Custom fields not available.
        }

        return [
            'name'                => $course->fullname,
            'shortname'           => $course->shortname,
            'campus'              => $campus,
            'startdate'           => (int)$course->startdate,
            'enddate'             => (int)$course->enddate,
            'total_hours'         => $totalhours,
            'student_count'       => $studentcount,
            'exam_count_platform' => $examcount,
            'exam_count_scorm'    => $scormcount,
            'lesson_count'        => $lessoncount,
            'videoconf_count'     => $videoconfcount,
            'tutor_count'         => $tutorcount,
        ];
    }

    /**
     * Get the list of tutors (teachers) enrolled in a course.
     *
     * @param int $courseid
     * @return array Each: [id, fullname, username, email, first_access, last_access]
     */
    public static function get_course_tutors(int $courseid): array {
        global $DB;

        $context = \context_course::instance($courseid);
        $teachers = get_enrolled_users($context, 'moodle/course:update', 0,
            'u.id, u.firstname, u.lastname, u.username, u.email, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');

        $tutors = [];
        foreach ($teachers as $teacher) {
            $sql = "SELECT MIN(l.timecreated) AS first_access, MAX(l.timecreated) AS last_access
                      FROM {logstore_standard_log} l
                     WHERE l.userid = :userid AND l.courseid = :courseid";
            $access = $DB->get_record_sql($sql, ['userid' => $teacher->id, 'courseid' => $courseid]);

            $tutors[] = [
                'id'           => (int)$teacher->id,
                'fullname'     => fullname($teacher),
                'username'     => $teacher->username,
                'email'        => $teacher->email,
                'first_access' => $access && $access->first_access ? (int)$access->first_access : 0,
                'last_access'  => $access && $access->last_access ? (int)$access->last_access : 0,
            ];
        }
        return $tutors;
    }

    /**
     * Get the list of students enrolled in a course.
     *
     * @param int $courseid
     * @return array Each: [id, fullname, username, email, idnumber]
     */
    public static function get_course_students(int $courseid): array {
        $context = \context_course::instance($courseid);
        $students = get_enrolled_users($context, 'mod/assign:submit', 0,
            'u.id, u.firstname, u.lastname, u.username, u.email, u.idnumber, u.firstnamephonetic, u.lastnamephonetic, u.middlename, u.alternatename');

        $result = [];
        foreach ($students as $student) {
            $result[] = [
                'id'       => (int)$student->id,
                'fullname' => fullname($student),
                'username' => $student->username,
                'email'    => $student->email,
                'idnumber' => $student->idnumber ?? '',
            ];
        }
        return $result;
    }


    // =========================================================================
    // 6. DETAILED CONNECTION LOG (entry/exit/elapsed/IP per session)
    // =========================================================================

    /**
     * Get detailed connection sessions (entry time, exit time, elapsed, IP).
     *
     * @param int $userid
     * @param int $courseid
     * @param int $sessionlimit Session gap limit in seconds (default 14400 = 4h).
     * @return array Each: [entry_time, exit_time, elapsed_seconds, ip]
     */
    public static function get_detailed_connections(int $userid, int $courseid, int $sessionlimit = 14400): array {
        global $DB;

        $sql = "SELECT l.id, l.timecreated, l.ip, l.eventname
                  FROM {logstore_standard_log} l
                 WHERE l.userid = :userid
                   AND l.courseid = :courseid
              ORDER BY l.timecreated ASC, l.id ASC";
        $logs = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);

        if (empty($logs)) {
            return [];
        }

        $sessions = [];
        $sessionstart = null;
        $sessionip = '';
        $lasttime = null;

        foreach ($logs as $log) {
            $currenttime = (int)$log->timecreated;
            $islogin = ((string)($log->eventname ?? '') === '\\core\\event\\user_loggedin');

            if ($sessionstart === null) {
                $sessionstart = $currenttime;
                $sessionip = $log->ip ?? '';
                $lasttime = $currenttime;
                continue;
            }

            $delta = $currenttime - $lasttime;

            if ($delta > $sessionlimit || $islogin) {
                $elapsed = $lasttime - $sessionstart;
                if ($elapsed > 0) {
                    $sessions[] = [
                        'entry_time'      => $sessionstart,
                        'exit_time'       => $lasttime,
                        'elapsed_seconds' => $elapsed,
                        'ip'              => $sessionip,
                    ];
                }
                $sessionstart = $currenttime;
                $sessionip = $log->ip ?? '';
            }

            $lasttime = $currenttime;
        }

        // Close the last session.
        if ($sessionstart !== null && $lasttime !== null && $lasttime > $sessionstart) {
            $sessions[] = [
                'entry_time'      => $sessionstart,
                'exit_time'       => $lasttime,
                'elapsed_seconds' => $lasttime - $sessionstart,
                'ip'              => $sessionip,
            ];
        }

        return $sessions;
    }


    // =========================================================================
    // 7. SCORM DETAIL
    // =========================================================================

    /**
     * Get SCORM activity details for a user in a course.
     *
     * @param int $userid
     * @param int $courseid
     * @return array Each: [scorm_name, sco_name, first_access, time_spent, status, grade]
     */
    public static function get_scorm_details(int $userid, int $courseid): array {
        global $DB;

        $sql = "SELECT sst.id AS trackid, s.id AS scormid, s.name AS scorm_name,
                       sst.scoid, ss.title AS sco_name,
                       sst.timemodified AS track_time,
                       sst.value AS track_value,
                       sst.element
                  FROM {scorm} s
                  JOIN {scorm_scoes} ss ON ss.scorm = s.id
                  JOIN {scorm_scoes_track} sst ON sst.scoid = ss.id AND sst.userid = :userid
                 WHERE s.course = :courseid
              ORDER BY s.name ASC, ss.sortorder ASC, sst.element ASC";

        try {
            $records = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);
        } catch (\Throwable $e) {
            return [];
        }

        $bysco = [];
        foreach ($records as $rec) {
            $key = $rec->scormid . '_' . $rec->scoid;
            if (!isset($bysco[$key])) {
                $bysco[$key] = [
                    'scorm_name'   => $rec->scorm_name,
                    'sco_name'     => $rec->sco_name,
                    'first_access' => 0,
                    'time_spent'   => '',
                    'status'       => '',
                    'grade'        => '',
                ];
            }

            $element = $rec->element;
            $value = $rec->track_value;
            $tracktime = (int)$rec->track_time;

            if (in_array($element, ['cmi.core.total_time', 'cmi.total_time'], true)) {
                $bysco[$key]['time_spent'] = (string)$value;
            } else if (in_array($element, ['cmi.core.lesson_status', 'cmi.completion_status', 'cmi.success_status'], true)) {
                $bysco[$key]['status'] = (string)$value;
            } else if (in_array($element, ['cmi.core.score.raw', 'cmi.score.raw'], true)) {
                $bysco[$key]['grade'] = (string)$value;
            }

            if ($tracktime > 0 && ($bysco[$key]['first_access'] === 0 || $tracktime < $bysco[$key]['first_access'])) {
                $bysco[$key]['first_access'] = $tracktime;
            }
        }

        return array_values($bysco);
    }


    // =========================================================================
    // 8. EVALUATION DETAILS
    // =========================================================================

    /**
     * Get evaluation (quiz/assign) details for a user in a course.
     *
     * @param int $userid
     * @param int $courseid
     * @return array Each: [name, type, grade, max_grade, date, status, section_name]
     */
    public static function get_evaluation_details(int $userid, int $courseid): array {
        global $DB;

        $sql = "SELECT gi.id AS itemid, gi.itemname, gi.itemmodule, gi.iteminstance,
                       gi.grademax, gi.categoryid,
                       gg.finalgrade, gg.timemodified AS graded_date,
                       cs.name AS section_name, cs.section AS section_num
                  FROM {grade_items} gi
             LEFT JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.userid = :userid
             LEFT JOIN {course_modules} cm ON cm.instance = gi.iteminstance
                       AND cm.course = gi.courseid
                       AND cm.module = (SELECT id FROM {modules} WHERE name = gi.itemmodule)
             LEFT JOIN {course_sections} cs ON cs.id = cm.section
                 WHERE gi.courseid = :courseid
                   AND gi.itemtype = 'mod'
              ORDER BY cs.section ASC, gi.sortorder ASC";

        try {
            $records = $DB->get_records_sql($sql, ['userid' => $userid, 'courseid' => $courseid]);
        } catch (\Throwable $e) {
            return [];
        }

        $results = [];
        foreach ($records as $rec) {
            $grade = $rec->finalgrade !== null ? round((float)$rec->finalgrade, 2) : null;
            $maxgrade = $rec->grademax !== null ? round((float)$rec->grademax, 2) : null;

            $status = 'No calificado';
            if ($grade !== null) {
                $status = ($maxgrade > 0 && $grade >= ($maxgrade * 0.5)) ? 'Aprobado' : 'Suspenso';
            }

            $results[] = [
                'name'         => $rec->itemname ?? '',
                'type'         => $rec->itemmodule ?? '',
                'grade'        => $grade,
                'max_grade'    => $maxgrade,
                'date'         => $rec->graded_date ? (int)$rec->graded_date : 0,
                'status'       => $status,
                'section_name' => $rec->section_name ?? ('Seccion ' . ($rec->section_num ?? '?')),
            ];
        }
        return $results;
    }


    // =========================================================================
    // UTILITY METHODS
    // =========================================================================

    /**
     * Get an activity name from a course module ID.
     */
    private static function get_activity_name_by_cmid(int $cmid, string $modname): string {
        global $DB;

        if ($cmid <= 0 || empty($modname)) {
            return '';
        }
        try {
            $cm = $DB->get_record('course_modules', ['id' => $cmid], 'instance');
            if (!$cm) {
                return '';
            }
            $instance = $DB->get_record($modname, ['id' => $cm->instance], 'name');
            return $instance ? (string)$instance->name : '';
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * Get user IDs enrolled in a course with specific role archetypes.
     */
    private static function get_course_user_ids_by_archetypes(int $courseid, array $archetypes, int $excludeuserid = 0): array {
        global $DB;

        if (empty($archetypes)) {
            $context = \context_course::instance($courseid);
            $users = get_enrolled_users($context, '', 0, 'u.id');
            $ids = array_map(function ($u) { return (int)$u->id; }, $users);
        } else {
            $context = \context_course::instance($courseid);
            [$insql, $params] = $DB->get_in_or_equal($archetypes, SQL_PARAMS_NAMED, 'arch');
            $params['contextid'] = $context->id;

            $sql = "SELECT DISTINCT ra.userid
                      FROM {role_assignments} ra
                      JOIN {role} r ON r.id = ra.roleid
                     WHERE ra.contextid = :contextid
                       AND r.archetype $insql";
            $records = $DB->get_records_sql($sql, $params);
            $ids = array_map(function ($r) { return (int)$r->userid; }, $records);
        }

        if ($excludeuserid > 0) {
            $ids = array_filter($ids, function ($id) use ($excludeuserid) {
                return $id !== $excludeuserid;
            });
        }
        return array_values($ids);
    }

    /**
     * Load fullnames for a set of user IDs.
     */
    private static function load_user_fullnames(array $userids): array {
        global $DB;

        $userids = array_unique(array_filter($userids));
        if (empty($userids)) {
            return [];
        }

        [$insql, $params] = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED, 'ufn');
        $records = $DB->get_records_sql("SELECT id, firstname, lastname, firstnamephonetic, lastnamephonetic, middlename, alternatename FROM {user} WHERE id $insql", $params);

        $names = [];
        foreach ($records as $rec) {
            $names[(int)$rec->id] = fullname($rec);
        }
        return $names;
    }

    /**
     * Format seconds as "XXh XXm XXs".
     */
    public static function format_duration(int $seconds): string {
        if ($seconds <= 0) {
            return '0h 0m 0s';
        }
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        return "{$h}h {$m}m {$s}s";
    }

    /**
     * Format a timestamp as dd/mm/YYYY HH:MM.
     */
    public static function format_datetime(int $timestamp): string {
        return $timestamp > 0 ? date('d/m/Y H:i', $timestamp) : '-';
    }

    /**
     * Format a timestamp as dd/mm/YYYY.
     */
    public static function format_date(int $timestamp): string {
        return $timestamp > 0 ? date('d/m/Y', $timestamp) : '-';
    }
}
