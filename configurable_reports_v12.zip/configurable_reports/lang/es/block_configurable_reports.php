<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Cadenas de idioma (Español) para block_configurable_reports.
 *
 * @package    block_configurable_reports
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['scormadvancedgrades'] = 'Estadísticas de actividades y recursos';
$string['scorm_advanced_grades'] = 'Estadísticas de actividades y recursos';
$string['scormadvancedgrades_stat'] = 'Estadística';
$string['scormadvancedgrades_format'] = 'Formato';
$string['scormadvancedgrades_format_auto'] = 'Automático';
$string['scormadvancedgrades_format_text'] = 'Texto';
$string['scormadvancedgrades_format_number'] = 'Número';
$string['scormadvancedgrades_format_percent'] = 'Porcentaje';
$string['scormadvancedgrades_format_datetime'] = 'Fecha';
$string['scormadvancedgrades_addmultiplecolumns'] = 'Añadir varias columnas';
$string['scormadvancedgrades_addmultiple_title'] = 'Añadir varias columnas';
$string['scormadvancedgrades_addmultiple_intro'] = 'Selecciona columnas globales y actividades para añadir automáticamente estadísticas.';
$string['scormadvancedgrades_addmultiple_quizsection'] = 'Cuestionarios';

$string['scormadvancedgrades_addmultiple_assignsection'] = 'Tareas';
$string['scormadvancedgrades_addmultiple_forumsection'] = 'Foros';
$string['scormadvancedgrades_addmultiple_addassignscore'] = 'Añadir la puntuación de todas las tareas';
$string['scormadvancedgrades_addmultiple_addassignsubmissiondate'] = 'Añadir fechas de entrega de tareas';
$string['scormadvancedgrades_addmultiple_addassigngradedate'] = 'Añadir fechas de corrección de tareas';
$string['scormadvancedgrades_addmultiple_addassigngrader'] = 'Añadir usuario que ha corregido la tarea';
$string['scormadvancedgrades_addmultiple_addassignfeedback'] = 'Feedback en la entrega';
$string['scormadvancedgrades_addmultiple_addforumposts'] = 'Añadir número posts de los usuarios en el foro';
$string['scormadvancedgrades_addmultiple_addforumfirstpost'] = 'Añadir fecha del primer post';
$string['scormadvancedgrades_addmultiple_addforumlastpost'] = 'Añadir fecha del último post';
$string['scormadvancedgrades_addmultiple_chatsection'] = 'Chats';
$string['scormadvancedgrades_addmultiple_addchatmessages'] = 'Añadir número de mensajes en chats';
$string['scormadvancedgrades_addmultiple_addchatfirstmessage'] = 'Añadir primera fecha y hora en chats';
$string['scormadvancedgrades_addmultiple_addchatlastmessage'] = 'Añadir última fecha y hora en chats';
$string['scormadvancedgrades_addmultiple_noselection_chat'] = 'Debes seleccionar al menos un chat.';
$string['scormadvancedgrades_addmultiple_scormsection'] = 'SCORMs';
$string['scormadvancedgrades_addmultiple_addscormcompletiondate'] = 'Añadir fecha de finalización del SCORM';
$string['scormadvancedgrades_addmultiple_addsCormscore'] = 'Añadir puntuación del SCORM';
$string['scormadvancedgrades_addmultiple_addscormscocompleted'] = 'Añadir objetos SCO completados';
$string['scormadvancedgrades_addmultiple_addsCormdedicationtime'] = 'Añadir tiempo de dedicación en el SCORM';
$string['scormadvancedgrades_addmultiple_addsCormlastaccess'] = 'Añadir último acceso al SCORM';
$string['scormadvancedgrades_addmultiple_noselection_scorm'] = 'Debes seleccionar al menos un SCORM.';
$string['scormadvancedgrades_addmultiple_zoomsection'] = 'Zoom';
$string['scormadvancedgrades_addmultiple_addzoomduration'] = 'Añadir duración de las sesiones Zoom';
$string['scormadvancedgrades_addmultiple_addzoomjointime'] = 'Añadir hora de entrada a las sesiones Zoom';
$string['scormadvancedgrades_addmultiple_addzoomleavetime'] = 'Añadir hora de salida a las sesiones Zoom';
$string['scormadvancedgrades_addmultiple_addzoomip'] = 'Añadir IP al conectar a las sesiones Zoom';
$string['scormadvancedgrades_addmultiple_addzoomdurationinschedule'] = 'Agregar duración de las sesiones de Zoom dentro de los tiempos de programación de sesiones';
$string['scormadvancedgrades_addmultiple_noselection_zoom'] = 'Debes seleccionar al menos una sesión Zoom.';
$string['scormadvancedgrades_addmultiple_activitysectionheading'] = 'Selecciona de las actividades de tipo "{$a}"';
$string['scormadvancedgrades_addmultiple_addquizcompletiondate'] = 'Añadir la fecha de realización de todos los cuestionarios';
$string['scormadvancedgrades_addmultiple_addquizscore'] = 'Añadir la puntuación de todos los cuestionarios';
$string['scormadvancedgrades_addmultiple_addquizdedicationtime'] = 'Añadir el tiempo de dedicación de todos los cuestionarios';
$string['scormadvancedgrades_addmultiple_addquizopendate'] = 'Añadir la fecha de apertura de todos los cuestionarios';
$string['scormadvancedgrades_addmultiple_addquizfirstpassattempt'] = 'Añadir el primer intento aprobado de todos los cuestionarios';
$string['scormadvancedgrades_addmultiple_selectcol'] = 'Seleccionar';
$string['scormadvancedgrades_addmultiple_activitycol'] = 'Actividad';
$string['scormadvancedgrades_addmultiple_selectall'] = 'Seleccionar todo';
$string['scormadvancedgrades_addmultiple_clearall'] = 'Quitar selección';
$string['scormadvancedgrades_addmultiple_saved'] = 'Columnas añadidas correctamente.';
$string['scormadvancedgrades_addmultiple_noselection'] = 'Debes seleccionar al menos una actividad.';

$string['scormadvancedgrades_addmultiple_noselection_quiz'] = 'Debes seleccionar al menos un cuestionario.';
$string['scormadvancedgrades_addmultiple_noselection_assign'] = 'Debes seleccionar al menos una tarea.';
$string['scormadvancedgrades_addmultiple_noselection_forum'] = 'Debes seleccionar al menos un foro.';
$string['scormadvancedgrades_addmultiple_nometrics'] = 'Debes seleccionar al menos una opción de columnas.';
$string['scormadvancedgrades_addmultiple_fallbackname'] = 'Actividad {$a}';
$string['coursecustomfield'] = 'Campo de curso personalizado';
$string['coursecustomfield_field'] = 'Campo';
$string['coursecustomfield_group_standard'] = 'Campos estándar';
$string['coursecustomfield_group_custom'] = 'Campos personalizados';
$string['coursecustomfield_source_course'] = 'Tabla course';
$string['coursecustomfield_source_custom'] = 'Campo personalizado de curso';
$string['course_custom_fields'] = 'Campo de curso personalizado';
$string['course_custom_fields_field'] = 'Campo';
$string['course_custom_fields_group_standard'] = 'Campos estándar';
$string['course_custom_fields_group_custom'] = 'Campos personalizados';
$string['course_custom_fields_source_course'] = 'Tabla course';
$string['course_custom_fields_source_custom'] = 'Campo personalizado de curso';
$string['userstatsadvanced'] = 'Estadísticas avanzadas del usuario';
$string['user_stats_advanced'] = 'Estadísticas avanzadas del usuario';
$string['userstatsadvanced_stattype'] = 'Tipo de estadística';
$string['userstatsadvanced_actividades_aprendizaje'] = 'Actividades de aprendizaje (completadas / total)';
$string['userstatsadvanced_actividades_aprendizaje_moodle_completion'] = 'Tareas completadas / Total (criterio de finalización Moodle)';
$string['userstatsadvanced_evaluaciones'] = 'Evaluaciones (completadas / total)';
$string['userstatsadvanced_contenidos_visualizados'] = 'Recursos visitados / total';
$string['userstatsadvanced_recursos_completados'] = 'Recursos completados / Total';
$string['userstatsadvanced_correos'] = 'Correos (interacción con docentes)';
$string['userstatsadvanced_mensajes_alumnos'] = 'Mensajes con alumnos';
$string['userstatsadvanced_registros'] = 'Registros (eventos en logs)';
$string['userstatsadvanced_dias_conexion'] = 'Días de conexión';
$string['userstatsadvanced_interacciones_foros'] = 'Interacciones en foros';
$string['userstatsadvanced_mensajes_foro'] = 'Mensajes en foro';
$string['userstatsadvanced_ips_utilizadas'] = 'IPs utilizadas';
$string['userstatsadvanced_ultima_ip'] = 'Última IP';
$string['userstatsadvanced_nota_final'] = 'Nota final del curso';
$string['userstatsadvanced_primer_acceso'] = 'Primer acceso';
$string['userstatsadvanced_ultimo_acceso'] = 'Último acceso';
$string['userstatsadvanced_primer_acceso_scorm'] = 'Primer acceso SCORM';
$string['userstatsadvanced_matricula_activa'] = 'Matrícula activa';
$string['userstatsadvanced_scorm_completados'] = 'SCORM completados/aprobados';
$string['userstatsadvanced_mensajes_tutor'] = 'Mensajes al tutor';
$string['userstatsadvanced_foros_publicados'] = 'Mensajes publicados en foros';
$string['userstatsadvanced_tareas_entregadas'] = 'Tareas entregadas';
$string['userstatsadvanced_intentos_cuestionario'] = 'Intentos de cuestionario';
$string['userstatsadvanced_evaluaciones_moodle_completion'] = 'Cuestionarios completados / Total (criterio de finalización Moodle)';
$string['userstatsadvanced_finalizacion_cruzada'] = 'Finalización cruzada';
$string['userstatsadvanced_logs_integracion'] = 'Eventos de integración';
$string['userstatsadvanced_tiempo_total'] = 'Tiempo total de dedicación (formato horas)';
$string['userstatsadvanced_tiempos_conexion_diarios_html'] = 'Tabla HTML de tiempos de conexión diarios';
$string['userstatsadvanced_maxdisplayvalue'] = 'Valor máximo que se mostrará (0-100)';
$string['userstatsadvanced_maxdisplayvalue_error'] = 'El valor máximo debe estar entre 0 y 100.';
$string['userstatsadvanced_displayformat'] = 'Formato de visualización';
$string['userstatsadvanced_displayformat_numdenum_percent'] = 'Num / Denum (%)';
$string['userstatsadvanced_displayformat_percent'] = '%';
$string['userstatsadvanced_displayformat_progress'] = 'Barra de progreso';
$string['userstatsadvanced_modalreport'] = 'Mostrar informe enlazado en ventana modal';
$string['userstatsadvanced_modalreport_no'] = 'No';
$string['userstatsadvanced_modalreport_open'] = 'Ver detalle';
$string['userstatsadvanced_download_pdf'] = 'Descargar informe PDF';
$string['userstatsadvanced_informe_pdf'] = 'Botón de descarga de informe PDF';
$string['report'] = 'Informe';
$string['exporttemplate'] = 'Exportar plantilla';
$string['viewreport'] = 'Ver informe';
$string['actualizarregistros'] = 'Actualizar registros';
$string['coursesectionsconfig'] = 'Configurar las secciones del curso';
$string['coursesections_disable'] = 'Deshabilitar funcionalidad de secciones del curso';
$string['userstatsadvanced_view_message'] = 'Ver mensaje';
$string['userstatsadvanced_messages_detail'] = 'Detalle de mensajes';
$string['userstatsadvanced_forum_messages_detail'] = 'Detalle de mensajes del foro';
$string['userstatsadvanced_from'] = 'De';
$string['userstatsadvanced_to'] = 'A';
$string['userstatsadvanced_forum'] = 'Foro';
$string['userstatsadvanced_subject'] = 'Asunto';
$string['userstatsadvanced_message'] = 'Mensaje';
$string['userstatsadvanced_created'] = 'Creado';
$string['userstatsadvanced_students_group'] = 'Alumnado';
$string['userstatsadvanced_user_label'] = 'Usuario';
$string['userstatsadvanced_no_subject'] = '-';
$string['userstatsadvanced_deleted_message'] = 'Mensaje eliminado';
$string['userstatsadvanced_select_quizzes'] = 'Seleccionar cuestionarios';
$string['userstatsadvanced_select_quizzes_help'] = 'Si no seleccionas cuestionarios, se usarán todos los cuestionarios visibles del curso.';
$string['userstatsadvanced_selected_quizzes_count'] = 'Cuestionarios seleccionados: {$a}';
$string['userstatsadvanced_elements_filter_default_quizzes'] = 'Acceso al curso y cuestionarios';
$string['userstatsadvanced_select_tasks'] = 'Seleccionar tareas';
$string['userstatsadvanced_select_tasks_help'] = 'Si no seleccionas tareas, se usarán todas las tareas visibles del curso.';
$string['userstatsadvanced_select_completed_resources_help'] = 'Si no seleccionas elementos, se usarán todos los recursos completados del curso.';
$string['userstatsadvanced_selected_tasks_count'] = 'Tareas seleccionadas: {$a}';
$string['userstatsadvanced_elements_filter_default_tasks'] = 'Acceso al curso y tareas';
$string['userstatsadvanced_elements_filter_default_completed_resources'] = 'Se usarán todos los recursos completados del curso.';
$string['reportcachewarning'] = 'Se están mostrando datos obtenidos desde caché para este informe. Si deseas forzar el recálculo, pulsa {$a}.';
$string['refreshreporttab'] = 'Actualizar';
$string['refreshreportdata'] = 'Actualizar registros';
$string['reportcacherefreshed'] = 'Los datos del informe se recalcularon correctamente.';
$string['userfield_column_id'] = 'ID';
$string['userfield_column_auth'] = 'Método de autenticación';
$string['userfield_column_confirmed'] = 'Cuenta confirmada';
$string['userfield_column_policyagreed'] = 'Política aceptada';
$string['userfield_column_deleted'] = 'Eliminado';
$string['userfield_column_suspended'] = 'Suspendido';
$string['userfield_column_mnethostid'] = 'Host MNet';
$string['userfield_column_emailstop'] = 'Correo deshabilitado';
$string['filteraccessscope'] = 'Alcance de acceso';
$string['filteraccessscope_summary'] = 'Alterna entre eventos solo del curso y eventos de curso + plataforma';
$string['filteraccessscope_courseonly'] = 'Solo curso';
$string['filteraccessscope_courseplatform'] = 'Curso + plataforma (courseid = 0)';
$string['exportmetadata_generatedat'] = 'Generado el';
$string['exportmetadata_scope'] = 'Alcance de acceso';
$string['exportmetadata_startdate'] = 'Fecha inicio';
$string['exportmetadata_enddate'] = 'Fecha fin';

// Legacy viewer strings.
$string['legacy_scenario_frozen'] = 'Datos legacy (curso finalizado)';
$string['legacy_scenario_live'] = 'Datos en vivo (itop activo)';
$string['legacy_scenario_own'] = 'Informes configurables (propio)';
$string['legacy_scenario_unknown'] = 'Escenario desconocido';
$string['legacy_view_title'] = 'Visor de datos legacy';
$string['legacy_breadcrumb'] = 'Datos legacy';
$string['legacy_no_itop_data'] = 'Este curso no tiene datos del sistema anterior. Redirigiendo a informes configurables.';
$string['legacy_no_data'] = 'No hay datos disponibles para esta sección.';
$string['legacy_readonly_notice'] = 'Datos de solo lectura — preservados para custodia de auditoría.';
$string['legacy_nav_label'] = 'Datos legacy (auditoría)';
$string['legacy_tab_summary'] = 'Resumen';
$string['legacy_tab_dedication'] = 'Dedicación';
$string['legacy_tab_scorm'] = 'SCORM';
$string['legacy_tab_videoconf'] = 'Videoconferencia';
$string['legacy_tab_daily'] = 'Estadísticas diarias';
$string['legacy_tab_values'] = 'Valores predefinidos';
$string['legacy_summary_students'] = 'Estudiantes';
$string['legacy_summary_avgdedication'] = 'Dedicación promedio';
$string['legacy_summary_coursehours'] = 'Horas del curso';
$string['legacy_summary_scorms'] = 'Actividades SCORM';
$string['legacy_summary_videoconf'] = 'Registros videoconf.';
$string['legacy_summary_datarange'] = 'Rango de datos';
$string['legacy_col_userid'] = 'ID usuario';
$string['legacy_col_firstname'] = 'Nombre';
$string['legacy_col_lastname'] = 'Apellido';
$string['legacy_col_email'] = 'Correo';
$string['legacy_col_dedication_seconds'] = 'Dedicación (seg.)';
$string['legacy_col_dedication_formatted'] = 'Dedicación';
$string['legacy_col_graceperiods'] = 'Períodos de gracia';
$string['legacy_col_coursehours'] = 'Horas curso';
$string['legacy_col_passhours'] = 'Horas aprobación';
$string['legacy_col_trackingmethod'] = 'Método seguimiento';
$string['legacy_col_timemodified'] = 'Última modificación';
$string['legacy_col_scormname'] = 'Nombre SCORM';
$string['legacy_col_scoid'] = 'SCO ID';
$string['legacy_col_attempt'] = 'Intento';
$string['legacy_col_jointime'] = 'Hora entrada';
$string['legacy_col_leavetime'] = 'Hora salida';
$string['legacy_col_duration'] = 'Duración';
$string['legacy_col_stat'] = 'Estadística';
$string['legacy_col_value'] = 'Valor';
$string['legacy_col_date'] = 'Fecha';
$string['legacy_col_reportname'] = 'Nombre informe';
$string['legacy_export_heading'] = 'Exportar datos legacy';
$string['legacy_export_dedication'] = 'Exportar dedicación (Excel)';
$string['legacy_export_scorm'] = 'Exportar SCORM (Excel)';
$string['legacy_export_summary'] = 'Exportar resumen (Excel)';
$string['legacy_export_metadata'] = 'Metadatos';
$string['legacy_export_title'] = 'Informe de datos legacy — Configurable Reports';
$string['legacy_export_scenario'] = 'Escenario';
$string['legacy_export_source'] = 'Fuente de datos';
$string['legacy_export_readonly'] = 'Solo lectura';
$string['legacy_export_course'] = 'Curso';
$string['legacy_export_startdate'] = 'Fecha de inicio';
$string['legacy_export_enddate'] = 'Fecha de fin';
$string['legacy_export_students'] = 'Total estudiantes';
$string['legacy_export_avgdedication'] = 'Dedicación promedio';
$string['legacy_export_coursehours'] = 'Horas del curso';
$string['legacy_export_firstrecord'] = 'Primer registro';
$string['legacy_export_lastrecord'] = 'Último registro';
$string['legacy_export_generated'] = 'Generado el';
$string['legacy_watermark'] = 'Datos legacy preservados para custodia — Exportado el {$a}';
// Configuración de tiempos a nivel de curso.
$string['coursetimeconfig'] = 'Configuración de tiempos';
$string['maxdailyhours'] = 'Máx. horas de acceso diario';
$string['maxdailyhours_help'] = 'Número máximo de horas por día a computar para cada estudiante en los informes de tiempo. Si un estudiante registra más de este valor en un solo día, el sistema lo limitará a este número. Establezca 0 (predeterminado) para desactivar el límite y mantener el comportamiento actual.';
$string['maxdailyhours_error'] = 'El valor debe ser 0 o un número positivo.';
$string['maxdailyhours_error_max'] = 'El valor no puede superar las 24 horas por día.';

// Consolidación de tiempos diarios.
$string['task_consolidate_daily_times'] = 'Consolidar tiempos de conexión diarios';
$string['consolidation_header'] = 'Consolidación de tiempos';
$string['consolidation_desc'] = 'Pre-calcular los tiempos de conexión diarios para todos los estudiantes inscritos en este curso. Esto acelera los informes de seguimiento de tiempo. El sistema también ejecuta esto automáticamente cada noche a las 2:00 AM.';
$string['consolidation_run'] = 'Consolidar tiempos ahora';
$string['consolidation_lastrun'] = 'Última consolidación';
$string['consolidation_success'] = 'Consolidación completada: {$a->users} usuarios procesados, {$a->records} registros escritos/actualizados.';
$string['consolidation_notable'] = 'La tabla de consolidación aún no existe. Por favor, actualice el plugin primero.';
