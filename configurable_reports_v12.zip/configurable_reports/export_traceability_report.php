<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Exports the Traceability Report (Informe de Trazabilidad) as PDF.
 *
 * Can generate a report for a single user or for the entire course.
 *
 * URL params:
 *   courseid – course ID (required)
 *   userid   – target user ID (optional; 0 or omitted = full course report)
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// PDF download: do NOT set NO_OUTPUT_BUFFERING; we need ob to prevent early output.

require_once('../../config.php');

$pdflibpath = $CFG->libdir . '/pdflib.php';
if (!file_exists($pdflibpath)) {
    throw new moodle_exception('error', '', '', null, 'PDF library (lib/pdflib.php) not found.');
}
require_once($pdflibpath);

// ── Parameters & security ─────────────────────────────────────────────────────

$courseid = required_param('courseid', PARAM_INT);
$userid   = optional_param('userid', 0, PARAM_INT);

require_login();

$course  = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
$context = context_course::instance($courseid);
$PAGE->set_context($context);

// Must be teacher/manager to generate the full report.
if ($userid > 0 && (int)$USER->id !== $userid) {
    require_capability('block/configurable_reports:manageownreports', $context);
} else if ($userid === 0) {
    require_capability('block/configurable_reports:manageownreports', $context);
}

// Load the traceability helper.
require_once($CFG->dirroot . '/blocks/configurable_reports/classes/traceability_helper.php');
use block_configurable_reports\traceability_helper;

// Also load the userstatsadvanced plugin for reusable methods.
require_once($CFG->dirroot . '/blocks/configurable_reports/plugin.class.php');
require_once($CFG->dirroot . '/blocks/configurable_reports/components/columns/userstatsadvanced/plugin.class.php');

// ── HTML escape helper ────────────────────────────────────────────────────────

$esc = function (string $text): string {
    // Convert to ISO-8859-1 safe chars then escape HTML.
    return htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};

// ── CSS Styles ────────────────────────────────────────────────────────────────

$css = '
<style>
    body { font-family: helvetica; font-size: 9pt; }
    h1 { font-size: 14pt; color: #003670; margin-bottom: 5px; }
    h2 { font-size: 11pt; color: #003670; margin-top: 10px; margin-bottom: 5px; border-bottom: 1px solid #0ABCC9; padding-bottom: 3px; }
    h3 { font-size: 10pt; color: #01264C; margin-top: 8px; margin-bottom: 4px; }
    table { border-collapse: collapse; width: 100%; margin-bottom: 8px; }
    th { background-color: #003670; color: #FFFFFF; padding: 4px 6px; text-align: left; font-size: 8pt; font-weight: bold; }
    td { padding: 3px 6px; font-size: 8pt; border-bottom: 1px solid #E2E6F2; }
    tr.alt { background-color: #F0F3FC; }
    .summary-box { background-color: #F0F3FC; padding: 8px; border: 1px solid #E2E6F2; margin-bottom: 10px; }
    .label { font-weight: bold; color: #01264C; }
    .accent { color: #0ABCC9; font-weight: bold; }
    .section-sep { border: 0; border-top: 2px solid #0ABCC9; margin: 12px 0; }
</style>';

// ── Build the report ──────────────────────────────────────────────────────────

$html = $css;

// Course summary header.
$summary = traceability_helper::get_course_summary($courseid);

$html .= '<h1>' . $esc($summary['name']) . '</h1>';
$html .= '<div class="summary-box">';
$html .= '<table>';
$html .= '<tr><td class="label">Campus/Sede:</td><td>' . $esc($summary['campus'] ?: 'N/A') . '</td>';
$html .= '<td class="label">Fecha inicio:</td><td>' . traceability_helper::format_date($summary['startdate']) . '</td></tr>';
$html .= '<tr><td class="label">Horas totales:</td><td>' . (int)$summary['total_hours'] . 'h</td>';
$html .= '<td class="label">Fecha fin:</td><td>' . traceability_helper::format_date($summary['enddate']) . '</td></tr>';
$html .= '<tr><td class="label">N&ordm; Alumnos:</td><td>' . $summary['student_count'] . '</td>';
$html .= '<td class="label">N&ordm; Tutores:</td><td>' . $summary['tutor_count'] . '</td></tr>';
$html .= '<tr><td class="label">Ex&aacute;menes plataforma:</td><td>' . $summary['exam_count_platform'] . '</td>';
$html .= '<td class="label">Paquetes SCORM:</td><td>' . $summary['exam_count_scorm'] . '</td></tr>';
$html .= '<tr><td class="label">Actividades:</td><td>' . $summary['lesson_count'] . '</td>';
$html .= '<td class="label">Videoconferencias:</td><td>' . $summary['videoconf_count'] . '</td></tr>';
$html .= '</table>';
$html .= '</div>';

// ── TUTORS SECTION ────────────────────────────────────────────────────────────

$tutors = traceability_helper::get_course_tutors($courseid);

if (!empty($tutors)) {
    $html .= '<h2>TUTORES / FORMADORES</h2>';
    $html .= '<table>';
    $html .= '<tr><th>Nombre</th><th>Usuario</th><th>Primer acceso</th><th>Ultimo acceso</th>';
    $html .= '<th>Tiempo tareas</th><th>Tiempo tutoria</th><th>Conexiones</th></tr>';

    $alt = false;
    foreach ($tutors as $tutor) {
        $timebreak = traceability_helper::get_tutor_time_breakdown($tutor['id'], $courseid);
        $connections = traceability_helper::get_detailed_connections($tutor['id'], $courseid);
        $rowclass = $alt ? ' class="alt"' : '';
        $alt = !$alt;

        $html .= '<tr' . $rowclass . '>';
        $html .= '<td>' . $esc($tutor['fullname']) . '</td>';
        $html .= '<td>' . $esc($tutor['username']) . '</td>';
        $html .= '<td>' . traceability_helper::format_datetime($tutor['first_access']) . '</td>';
        $html .= '<td>' . traceability_helper::format_datetime($tutor['last_access']) . '</td>';
        $html .= '<td>' . traceability_helper::format_duration($timebreak['task_correction_seconds']) . '</td>';
        $html .= '<td>' . traceability_helper::format_duration($timebreak['tutoring_seconds']) . '</td>';
        $html .= '<td>' . count($connections) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</table>';
}

// ── STUDENTS SECTION ──────────────────────────────────────────────────────────

$students = traceability_helper::get_course_students($courseid);

// If a specific user was requested, filter to just that one.
if ($userid > 0) {
    $students = array_filter($students, function ($s) use ($userid) {
        return $s['id'] === $userid;
    });
    $students = array_values($students);
}

if (!empty($students)) {
    // Summary table.
    $html .= '<h2>RESUMEN DE ALUMNOS</h2>';
    $html .= '<table>';
    $html .= '<tr><th>Nombre</th><th>Usuario</th><th>Primer acceso</th><th>Ultimo acceso</th>';
    $html .= '<th>Videoconf.</th><th>Materiales</th><th>Mensajes</th></tr>';

    $alt = false;
    foreach ($students as $student) {
        $vccount = traceability_helper::count_videoconference_sessions($student['id'], $courseid);
        $matcount = count(traceability_helper::get_accessed_materials($student['id'], $courseid));
        $msgcount = count(traceability_helper::get_complete_messages($student['id'], $courseid, ['editingteacher', 'teacher']));

        // Get first/last access from logstore.
        $conns = traceability_helper::get_detailed_connections($student['id'], $courseid);
        $firstaccess = !empty($conns) ? $conns[0]['entry_time'] : 0;
        $lastaccess = !empty($conns) ? end($conns)['exit_time'] : 0;

        $rowclass = $alt ? ' class="alt"' : '';
        $alt = !$alt;

        $html .= '<tr' . $rowclass . '>';
        $html .= '<td>' . $esc($student['fullname']) . '</td>';
        $html .= '<td>' . $esc($student['username']) . '</td>';
        $html .= '<td>' . traceability_helper::format_datetime($firstaccess) . '</td>';
        $html .= '<td>' . traceability_helper::format_datetime($lastaccess) . '</td>';
        $html .= '<td>' . $vccount . '</td>';
        $html .= '<td>' . $matcount . '</td>';
        $html .= '<td>' . $msgcount . '</td>';
        $html .= '</tr>';
    }
    $html .= '</table>';

    // ── INDIVIDUAL STUDENT FILES ──────────────────────────────────────────────

    foreach ($students as $student) {
        $html .= '<hr class="section-sep"/>';
        $html .= '<h2>FICHA INDIVIDUAL: ' . $esc($student['fullname']) . '</h2>';

        // Basic data.
        $html .= '<div class="summary-box">';
        $html .= '<table>';
        $html .= '<tr><td class="label">Nombre:</td><td>' . $esc($student['fullname']) . '</td>';
        $html .= '<td class="label">Usuario:</td><td>' . $esc($student['username']) . '</td></tr>';
        $html .= '<tr><td class="label">Email:</td><td>' . $esc($student['email']) . '</td>';
        $html .= '<td class="label">DNI/NIF:</td><td>' . $esc($student['idnumber']) . '</td></tr>';
        $html .= '</table></div>';

        $sid = $student['id'];

        // ── Detailed connections ──────────────────────────────────────────────
        $connections = traceability_helper::get_detailed_connections($sid, $courseid);
        if (!empty($connections)) {
            $html .= '<h3>Conexiones detalladas</h3>';
            $html .= '<table>';
            $html .= '<tr><th>Fecha/Hora entrada</th><th>Fecha/Hora salida</th><th>Tiempo transcurrido</th><th>IP</th></tr>';

            $alt = false;
            $totalelapsed = 0;
            foreach ($connections as $conn) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;
                $totalelapsed += $conn['elapsed_seconds'];

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . traceability_helper::format_datetime($conn['entry_time']) . '</td>';
                $html .= '<td>' . traceability_helper::format_datetime($conn['exit_time']) . '</td>';
                $html .= '<td>' . traceability_helper::format_duration($conn['elapsed_seconds']) . '</td>';
                $html .= '<td>' . $esc($conn['ip']) . '</td>';
                $html .= '</tr>';
            }
            $html .= '<tr><td colspan="2" class="label">TOTAL</td>';
            $html .= '<td class="accent">' . traceability_helper::format_duration($totalelapsed) . '</td>';
            $html .= '<td>' . count($connections) . ' sesiones</td></tr>';
            $html .= '</table>';
        }

        // ── Evaluations ──────────────────────────────────────────────────────
        $evaluations = traceability_helper::get_evaluation_details($sid, $courseid);
        if (!empty($evaluations)) {
            $html .= '<h3>Evaluaciones</h3>';
            $html .= '<table>';
            $html .= '<tr><th>Secci&oacute;n</th><th>Actividad</th><th>Tipo</th><th>Nota</th><th>Fecha</th><th>Estado</th></tr>';

            $alt = false;
            foreach ($evaluations as $eval) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;
                $gradetext = $eval['grade'] !== null
                    ? number_format($eval['grade'], 2) . ' / ' . number_format($eval['max_grade'], 2)
                    : '-';

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . $esc($eval['section_name']) . '</td>';
                $html .= '<td>' . $esc($eval['name']) . '</td>';
                $html .= '<td>' . $esc($eval['type']) . '</td>';
                $html .= '<td>' . $gradetext . '</td>';
                $html .= '<td>' . traceability_helper::format_datetime($eval['date']) . '</td>';
                $html .= '<td>' . $esc($eval['status']) . '</td>';
                $html .= '</tr>';
            }
            $html .= '</table>';
        }

        // ── SCORM Content ────────────────────────────────────────────────────
        $scorms = traceability_helper::get_scorm_details($sid, $courseid);
        if (!empty($scorms)) {
            $html .= '<h3>Contenidos SCORM</h3>';
            $html .= '<table>';
            $html .= '<tr><th>M&oacute;dulo</th><th>SCO</th><th>Primer acceso</th><th>Tiempo</th><th>Estado</th><th>Nota</th></tr>';

            $alt = false;
            foreach ($scorms as $scorm) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . $esc($scorm['scorm_name']) . '</td>';
                $html .= '<td>' . $esc($scorm['sco_name']) . '</td>';
                $html .= '<td>' . traceability_helper::format_datetime($scorm['first_access']) . '</td>';
                $html .= '<td>' . $esc($scorm['time_spent'] ?: '-') . '</td>';
                $html .= '<td>' . $esc($scorm['status'] ?: '-') . '</td>';
                $html .= '<td>' . $esc($scorm['grade'] ?: '-') . '</td>';
                $html .= '</tr>';
            }
            $html .= '</table>';
        }

        // ── Videoconferences ─────────────────────────────────────────────────
        $vcsessions = traceability_helper::get_videoconference_sessions($sid, $courseid);
        if (!empty($vcsessions)) {
            $html .= '<h3>Videoconferencias</h3>';
            $html .= '<table>';
            $html .= '<tr><th>Nombre</th><th>Fecha</th><th>Hora entrada</th><th>Duraci&oacute;n</th><th>Fuente</th></tr>';

            $alt = false;
            foreach ($vcsessions as $vc) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . $esc($vc['name']) . '</td>';
                $html .= '<td>' . $esc($vc['date']) . '</td>';
                $html .= '<td>' . ($vc['join_time'] > 0 ? date('H:i', $vc['join_time']) : '-') . '</td>';
                $html .= '<td>' . ($vc['duration_seconds'] > 0 ? traceability_helper::format_duration($vc['duration_seconds']) : '-') . '</td>';
                $html .= '<td>' . $esc($vc['source']) . '</td>';
                $html .= '</tr>';
            }
            $html .= '</table>';
        }

        // ── Material access ──────────────────────────────────────────────────
        $materials = traceability_helper::get_accessed_materials($sid, $courseid);
        if (!empty($materials)) {
            $html .= '<h3>Accesos a material did&aacute;ctico</h3>';
            $html .= '<table>';
            $html .= '<tr><th>Recurso</th><th>Tipo</th><th>Primer acceso</th><th>&Uacute;ltimo acceso</th><th>N&ordm; accesos</th></tr>';

            $alt = false;
            foreach ($materials as $mat) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . $esc($mat['name']) . '</td>';
                $html .= '<td>' . $esc($mat['modname']) . '</td>';
                $html .= '<td>' . traceability_helper::format_datetime($mat['first_access']) . '</td>';
                $html .= '<td>' . traceability_helper::format_datetime($mat['last_access']) . '</td>';
                $html .= '<td>' . $mat['access_count'] . '</td>';
                $html .= '</tr>';
            }
            $html .= '</table>';
        }

        // ── Complete messaging ───────────────────────────────────────────────
        $messages = traceability_helper::get_complete_messages($sid, $courseid, ['editingteacher', 'teacher']);
        if (!empty($messages)) {
            $html .= '<h3>Mensajer&iacute;a completa (tutor &harr; alumno)</h3>';
            $html .= '<table>';
            $html .= '<tr><th>Fecha</th><th>De</th><th>Para</th><th>Asunto</th><th>Mensaje</th></tr>';

            $alt = false;
            foreach ($messages as $msg) {
                $rowclass = $alt ? ' class="alt"' : '';
                $alt = !$alt;

                // Truncate body for PDF readability (max 500 chars per message).
                $bodytext = strip_tags($msg['body']);
                if (mb_strlen($bodytext) > 500) {
                    $bodytext = mb_substr($bodytext, 0, 497) . '...';
                }

                $html .= '<tr' . $rowclass . '>';
                $html .= '<td>' . traceability_helper::format_datetime($msg['timecreated']) . '</td>';
                $html .= '<td>' . $esc($msg['from_fullname']) . '</td>';
                $html .= '<td>' . $esc($msg['to_fullname']) . '</td>';
                $html .= '<td>' . $esc($msg['subject'] ?: '-') . '</td>';
                $html .= '<td style="font-size:7pt;">' . $esc($bodytext) . '</td>';
                $html .= '</tr>';
            }
            $html .= '</table>';
        }
    }
}

// ── Render PDF ────────────────────────────────────────────────────────────────

$pdf = new pdf('P', 'mm', 'A4', false, 'ISO-8859-1', false);
$pdf->SetCreator(format_string(get_site()->fullname));
$pdf->SetTitle('Informe de Trazabilidad - ' . format_string($course->fullname));
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 10);
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 8);

// Convert from UTF-8 to ISO-8859-1.
$html = mb_convert_encoding($html, 'ISO-8859-1', 'UTF-8');
$pdf->writeHTML($html, true, false, true, false, '');

// Filename.
$safecourse = preg_replace('/[^A-Za-z0-9\-]/', '_', strtoupper((string)($course->shortname ?? 'CURSO')));
if ($userid > 0) {
    $targetuser = $DB->get_record('user', ['id' => $userid], '*', MUST_EXIST);
    $safename = preg_replace('/[^A-Za-z0-9\-]/', '_', strtoupper(fullname($targetuser)));
    $filename = 'TRAZABILIDAD_' . $safecourse . '_' . $safename . '.pdf';
} else {
    $filename = 'TRAZABILIDAD_' . $safecourse . '_COMPLETO.pdf';
}

// Clean any stray output that Moodle or plugins may have sent.
while (ob_get_level() > 0) {
    ob_end_clean();
}
$pdf->Output($filename, 'D');
exit;
