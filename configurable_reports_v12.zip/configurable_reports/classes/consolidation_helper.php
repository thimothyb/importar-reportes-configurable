<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Helper class for consolidating daily connection times.
 *
 * Shared logic used by both the scheduled task (cron) and the manual
 * consolidation button on the course time config page.
 *
 * @package    block_configurable_reports
 * @copyright  2026 Awakelab
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_configurable_reports;

defined('MOODLE_INTERNAL') || die();

/**
 * Consolidation helper for pre-computing daily connection times.
 */
class consolidation_helper {

    /** @var int Default session gap limit in seconds (4 hours). */
    private const DEFAULT_SESSION_LIMIT = 14400;

    /** @var string Login event name to detect session breaks. */
    private const EVENT_USER_LOGGEDIN = '\\core\\event\\user_loggedin';

    /**
     * Consolidate daily connection times for a single course.
     *
     * Processes all enrolled users in the course, calculates their daily
     * connection times from logstore_standard_log, and upserts the results
     * into configurable_reports_diario.
     *
     * @param int $courseid The course to consolidate.
     * @param \progress_trace|null $trace Optional trace for cron output.
     * @return array Summary with keys: users_processed, records_written.
     */
    public static function consolidate_course(int $courseid, ?\progress_trace $trace = null): array {
        global $DB;

        if ($trace === null) {
            $trace = new \null_progress_trace();
        }

        $context = \context_course::instance($courseid, IGNORE_MISSING);
        if (!$context) {
            $trace->output("  Course {$courseid}: context not found, skipping.");
            return ['users_processed' => 0, 'records_written' => 0];
        }

        // Get all enrolled users in this course.
        $enrolledusers = get_enrolled_users($context, '', 0, 'u.id', null, 0, 0, true);
        if (empty($enrolledusers)) {
            $trace->output("  Course {$courseid}: no enrolled users, skipping.");
            return ['users_processed' => 0, 'records_written' => 0];
        }

        $now = time();
        $usersprocessed = 0;
        $recordswritten = 0;

        foreach ($enrolledusers as $user) {
            $dailytotals = self::calculate_daily_totals($user->id, $courseid);

            foreach ($dailytotals as $daybucket => $totalseconds) {
                $totalseconds = max(0, (int)$totalseconds);
                if ($totalseconds === 0) {
                    continue;
                }

                $existing = $DB->get_record('configurable_reports_diario', [
                    'userid' => $user->id,
                    'courseid' => $courseid,
                    'logdate' => $daybucket,
                ]);

                if ($existing) {
                    if ((int)$existing->tiempo_diario !== $totalseconds) {
                        $existing->tiempo_diario = $totalseconds;
                        $existing->timemodified = $now;
                        $DB->update_record('configurable_reports_diario', $existing);
                        $recordswritten++;
                    }
                } else {
                    $record = new \stdClass();
                    $record->userid = $user->id;
                    $record->courseid = $courseid;
                    $record->logdate = $daybucket;
                    $record->tiempo_diario = $totalseconds;
                    $record->timecreated = $now;
                    $record->timemodified = $now;
                    $DB->insert_record('configurable_reports_diario', $record);
                    $recordswritten++;
                }
            }

            $usersprocessed++;
        }

        $trace->output("  Course {$courseid}: {$usersprocessed} users processed, {$recordswritten} records written/updated.");
        return ['users_processed' => $usersprocessed, 'records_written' => $recordswritten];
    }

    /**
     * Consolidate all active courses that have the block installed.
     *
     * @param \progress_trace|null $trace Optional trace for cron output.
     * @return array Summary with keys: courses_processed, total_users, total_records.
     */
    public static function consolidate_all(?\progress_trace $trace = null): array {
        global $DB;

        if ($trace === null) {
            $trace = new \null_progress_trace();
        }

        $trace->output('Starting daily time consolidation for all courses...');

        // Find courses that have at least one configurable_reports block instance.
        $sql = "SELECT DISTINCT bi.parentcontextid
                  FROM {block_instances} bi
                 WHERE bi.blockname = 'configurable_reports'
                   AND bi.parentcontextid IN (
                       SELECT ctx.id FROM {context} ctx WHERE ctx.contextlevel = :contextlevel
                   )";
        $contextids = $DB->get_fieldset_sql($sql, ['contextlevel' => CONTEXT_COURSE]);

        if (empty($contextids)) {
            $trace->output('No courses with configurable_reports block found.');
            return ['courses_processed' => 0, 'total_users' => 0, 'total_records' => 0];
        }

        $coursesprocessed = 0;
        $totalusers = 0;
        $totalrecords = 0;

        foreach ($contextids as $contextid) {
            $ctxrecord = $DB->get_record('context', ['id' => $contextid], 'instanceid');
            if (!$ctxrecord) {
                continue;
            }
            $courseid = (int)$ctxrecord->instanceid;

            // Skip site-level.
            if ($courseid <= 1) {
                continue;
            }

            // Check course exists and is visible.
            $course = $DB->get_record('course', ['id' => $courseid], 'id, visible');
            if (!$course) {
                continue;
            }

            $result = self::consolidate_course($courseid, $trace);
            $coursesprocessed++;
            $totalusers += $result['users_processed'];
            $totalrecords += $result['records_written'];
        }

        $trace->output("Consolidation complete: {$coursesprocessed} courses, {$totalusers} users, {$totalrecords} records.");
        return [
            'courses_processed' => $coursesprocessed,
            'total_users' => $totalusers,
            'total_records' => $totalrecords,
        ];
    }

    /**
     * Calculate raw daily connection totals for a user in a course.
     *
     * Replicates the same logic as userstatsadvanced::get_daily_connection_totals()
     * but as a static method independent of the report column class.
     *
     * @param int $userid
     * @param int $courseid
     * @return array<int,int> Day bucket => total seconds.
     */
    private static function calculate_daily_totals(int $userid, int $courseid): array {
        global $DB;

        $params = [
            'userid' => $userid,
            'courseid' => $courseid,
            'contextcourse' => CONTEXT_COURSE,
            'contextmodule' => CONTEXT_MODULE,
            'targetcourse' => 'course',
            'actionviewedcourse' => 'viewed',
            'actionviewedmodule' => 'viewed',
            'crudread' => 'r',
            'crudcreate' => 'c',
            'crudupdate' => 'u',
        ];

        // Build the LIKE condition for mod_% components.
        $modlike = $DB->sql_like('l.component', ':modcomponentlike', false, false);
        $params['modcomponentlike'] = 'mod\_%';

        $courseeventsfilter = "(
            (
                l.contextlevel = :contextcourse
                AND l.target = :targetcourse
                AND l.action = :actionviewedcourse
            )
            OR
            (
                l.contextlevel = :contextmodule
                AND {$modlike}
                AND (
                    l.action = :actionviewedmodule
                    OR l.crud = :crudread
                    OR l.crud = :crudcreate
                    OR l.crud = :crudupdate
                )
            )
        )";

        $sql = "SELECT l.id, l.timecreated, l.eventname, FLOOR(l.timecreated / 86400) AS daybucket
                  FROM {logstore_standard_log} l
                 WHERE l.userid = :userid
                   AND l.courseid = :courseid
                   AND {$courseeventsfilter}
              ORDER BY l.timecreated ASC, l.id ASC";

        $logs = $DB->get_records_sql($sql, $params);

        if (!$logs) {
            return [];
        }

        $limitinseconds = self::DEFAULT_SESSION_LIMIT;
        $totalsbyday = [];
        $previousdaybucket = null;
        $previoustime = null;

        foreach ($logs as $log) {
            $daybucket = (int)$log->daybucket;
            $currenttime = (int)$log->timecreated;
            $isloginevent = ((string)($log->eventname ?? '') === self::EVENT_USER_LOGGEDIN);

            if (!array_key_exists($daybucket, $totalsbyday)) {
                $totalsbyday[$daybucket] = 0;
            }

            if ($previousdaybucket !== null && $daybucket === $previousdaybucket && $previoustime !== null) {
                $delta = $currenttime - $previoustime;
                if ($delta > 0 && $delta <= $limitinseconds && !$isloginevent) {
                    $totalsbyday[$daybucket] += $delta;
                }
            }

            $previousdaybucket = $daybucket;
            $previoustime = $currenttime;
        }

        ksort($totalsbyday, SORT_NUMERIC);
        return $totalsbyday;
    }
}
